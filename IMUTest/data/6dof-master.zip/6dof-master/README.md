# Sparkfun 6DOF
Arduino/processing code for the sparkfun 6DOF sensor: https://www.sparkfun.com/products/10121

For complete hookup and tutorial see bildr.org: http://bildr.org/2012/03/stable-orientation-digital-imu-6dof-arduino/

The code is provided under the MIT license please use, edit, change, and share. 

**Big Thanks to varesano.net for the freeimu code this is based off of.**

*Before loading the sixDOF_Example code, or even opening the arduino software, place the FreeSixIMU folder in your arduino library.*

##### ARDUINO LIBRARY LOCATION
* On your Mac:: In (home directory)/Documents/Arduino/libraries  
* On your PC:: My Documents -> Arduino -> libraries  
* On your Linux box: (home directory)/sketchbook/libraries  
